import java.util.Arrays;

public class SortAndPrintArray {
    public static void main(String[] args) {
        int[] arr = {12, 10, 6, 2, 1, 6, 11};

        // Sort the array in ascending order
        Arrays.sort(arr);

        // Initialize an empty result string
        StringBuilder result = new StringBuilder();

        // Iterate through the sorted array
        for (int i = 0; i < arr.length; i++) {
            result.append(arr[i]); // Add the number to the result
            if (i < arr.length - 1) {
                result.append(" * "); // If it's not the last element, add a "*"
            }
        }

        // Print the sorted array with "*" in between
        System.out.println(result.toString());
    }
}
