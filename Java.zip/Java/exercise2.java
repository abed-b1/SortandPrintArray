import java.util.Arrays;

public class RearrangeandPrint {
    public static void main(String[] args) {
        // Check if arguments are provided
        if (args.length == 0) {
            System.out.println("No arguments provided. Please provide space-separated numbers as arguments.");
            return;
        }

        // Convert the command-line arguments to integers
        int[] numbers = new int[args.length];
        for (int i = 0; i < args.length; i++) {
            numbers[i] = Integer.parseInt(args[i]);
        }

        // Sort the numbers in ascending order
        Arrays.sort(numbers);

        // Print the sorted numbers in separate lines
        for (int num : numbers) {
            System.out.println(num);
        }
    }
}
