import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;

public class FileIOExample {
    public static void main(String[] args) {
        // Specify the file path and name
        String filePath = "sample.txt";
        String content = "Hello, Java programming users.!!";
        
        try {
            // Create a new file and write content to it
            createAndWriteFile(filePath, content);
            
            // Display the file's contents using BufferedReader
            String fileContents = readFromFile(filePath);
            System.out.println(fileContents);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void createAndWriteFile(String filePath, String content) throws IOException {
        // Create a File object
        File file = new File(filePath);

        // Create the file if it doesn't exist
        if (!file.exists()) {
            System.out.println("File created!");
            file.createNewFile();
        }

        // Write the content to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(content);
        }
    }
    
    public static String readFromFile(String filePath) throws IOException {
        // Read the file's contents using BufferedReader
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath)) ) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        return content.toString();
    }
}
