import java.util.Scanner;

class Employee {
    protected int employeeId;
    protected String employeeName;

    public Employee(int employeeId, String employeeName) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
    }
}

class Company extends Employee {
    private double totalDuration;
    private double wagesPerHour;
    private int numberOfWeeks;

    public Company(int employeeId, String employeeName, double totalDuration, double wagesPerHour, int numberOfWeeks) {
        super(employeeId, employeeName);
        this.totalDuration = totalDuration;
        this.wagesPerHour = wagesPerHour;
        this.numberOfWeeks = numberOfWeeks;
    }

    public double wagesCalculation() {
        return totalDuration * wagesPerHour * numberOfWeeks;
    }

    public void displayWages() {
        double wages = wagesCalculation();
        System.out.println("EmployeeId: " + employeeId);
        System.out.println("EmployeeName: " + employeeName);
        System.out.printf("Wages: %.2f €%n", wages);
    }
}

public class WagesCalculation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter EmployeeId: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter EmployeeName: ");
        String employeeName = scanner.nextLine();

        System.out.print("Total duration: ");
        double totalDuration = scanner.nextDouble();

        Company employee = new Company(employeeId, employeeName, totalDuration, 10.0, 4);
        employee.displayWages();

        scanner.close();
    }
}
