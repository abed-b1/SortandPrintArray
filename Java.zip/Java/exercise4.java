import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadFileExample {
    public static void main(String[] args) {
        String filePath = "sample.txt";
        String content = "Java is a high-level, class-based, Object-oriented programming language.";

        try {
            // Create a new file and write content to it
            createAndWriteFile(filePath, content);
            
            // Check if the file can be read
            if (canReadFile(filePath)) {
                System.out.println("This File can Read!");

                // Read and print the specific content using BufferedReader offset
                String specificContent = readSpecificContent(filePath);
                System.out.println(specificContent);
            } else {
                System.out.println("This File cannot be read!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void createAndWriteFile(String filePath, String content) throws IOException {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(content);
        }
    }

    public static boolean canReadFile(String filePath) {
        try {
            FileReader fileReader = new FileReader(filePath);
            fileReader.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static String readSpecificContent(String filePath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // Offset is used to skip characters before reading
            reader.skip("Java is a high-level, class-based, ".length());
            return reader.readLine();
        }
    }
}
